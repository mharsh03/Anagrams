#!/usr/local/bin/python3

# -*- coding: utf-8 -*-


"""Convenience wrapper for running anagram_solver directly from source tree."""

from anagram_solver.anagram_solver import main

if __name__ == '__main__':
    main()
