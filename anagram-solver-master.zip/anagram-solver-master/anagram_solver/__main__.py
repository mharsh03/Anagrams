# -*- coding: utf-8 -*-


"""anagram_solver.__main__: executed when directory is called as script."""


from .anagram_solver import main

main()
